
namespace BeeAware.Models
{
    public class expToDB
    {
        int id;
        string name;    
        string description;
    }
    // have same structure as it is stored in database
}
