
namespace BeeAware.Models
{
    public class expToFrontEnd
    {
        string name;    
        string description;
    }
    // have same structure as it is stored in database
}
